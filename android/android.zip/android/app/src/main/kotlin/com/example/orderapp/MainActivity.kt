package com.example.orderapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
